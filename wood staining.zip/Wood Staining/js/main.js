$(document).ready(function () {
    console.log('JQUERY LOADED');

    $(".ScreenHint").hide();

    var courseConfigObj = {
        courseDataPath: "assets/data/CourseData.json",
        commonPagePath: "pages/html/",

        $screenContainer: $(".screenInner"),
        $contentContainer: $(".contentPart"),

        screenContainer: {
            $startBtn: $(".StartBtn"),
            $headerMenuContainer : $(".headerMenuLists"),
            isRequired: true
        }

    }

    var courseObj = new eLearningCourse(courseConfigObj);
    courseObj.onStartBtnClick();
});	