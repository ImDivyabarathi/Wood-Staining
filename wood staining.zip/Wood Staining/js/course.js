var eLearningCourse = function (courseConfigObj) {
    var _this = this;

    _this.courseDataPath = courseConfigObj.courseDataPath;
    _this.commonPagePath = courseConfigObj.commonPagePath;

    _this.$screenContainer = courseConfigObj.$screenContainer;
    _this.$contentContainer = courseConfigObj.$contentContainer;

    _this.$startBtn = courseConfigObj.screenContainer.$startBtn;
    _this.$headerMenuContainer = courseConfigObj.screenContainer.$headerMenuContainer;

    // this.loadCourseData = function(){
	// 	console.log("LOAD COURSE DATA");
	// 	console.log(_this.courseDataPath);
	// 	$.ajax({
	// 		url:_this.courseDataPath+"?version="+(new Date()).getTime(),
	// 		dataType : "json",
	// 		success:_this.onCourseDataLoadSuccess
	// 	});		
    // }
    // this.onCourseDataLoadSuccess = function(courseData){
	// 	console.log("onCourseDataLoadSuccess");
	// 	console.log(courseData);
		
	// 	_this.courseData = courseData.data;
	// 	_this.screenData = _this.courseData.screens;
	// 	_this.curScreenNo = 1;
	// 	_this.totalScreens = _this.screenData.length;
		

	// 	_this.addEvents();
	
	// }
    
    this.onStartBtnClick = function(){
		_this.$contentContainer.hide();
        _this.$screenContainer.show();
        _this.$headerMenuContainer.show();
	}
}