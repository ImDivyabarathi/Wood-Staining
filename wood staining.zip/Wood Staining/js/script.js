$(document).ready(function () {
    $(".startBtn").off('click').click(function () {
        $(".startPageContainer").hide();
        $(".contentPart").show();
        $(".headerMenuLists,.screen1").show();
        $( ".commonContainer" ).addClass( "commonContainerInner" );
    })
    $(".nextBtn").off('click').click(function () {
        $(".screen1").hide();
        $(".screen2").show();
    })
})
